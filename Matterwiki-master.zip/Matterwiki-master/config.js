module.exports = {
    'auth_secret': 'thisisasecretkeyforjwtauth'
};
