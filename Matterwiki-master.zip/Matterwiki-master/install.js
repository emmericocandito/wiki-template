#!/usr/bin/env node

/*
This script will be executed on the command "wiki". It is defined under the "bin" key in the package.json file.
This is where we will write the complete setup script.
Creating tables. Filling them with initial data. Creating the first user.

We're still looking for better names for the command. Should be matterwiki or just wiki?

TODO: Figure out how to create the database setup script integrating with knex and bookshelf.
*/
console.log("Installation started!");
