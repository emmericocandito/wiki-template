import Avatar from "./Avatar";
import AvatarWithPresence from "./AvatarWithPresence";

export { AvatarWithPresence };

export default Avatar;
