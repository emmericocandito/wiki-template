import Sidebar from "./App";

export default Sidebar;
