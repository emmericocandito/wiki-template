import * as React from "react";

export const id = "skip-nav";

export default function SkipNavContent() {
  return <div id={id} />;
}
