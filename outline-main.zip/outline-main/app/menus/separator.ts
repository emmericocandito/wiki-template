import { MenuSeparator } from "~/types";

export default function separator(): MenuSeparator {
  return {
    type: "separator",
  };
}
