import styled from "styled-components";
import Flex from "~/components/Flex";

const Container = styled(Flex)`
  position: relative;
`;

export default Container;
