export const runAllPromises = () => new Promise<void>(setImmediate);
