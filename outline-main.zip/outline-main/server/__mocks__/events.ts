export default {
  add: () => {
    // empty
  },
};
